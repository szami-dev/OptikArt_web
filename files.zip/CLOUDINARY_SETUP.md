# ═══════════════════════════════════════════════════════════════
# CLOUDINARY FIÓK LÉTREHOZÁS ÉS BEÁLLÍTÁS – LÉPÉSRŐL LÉPÉSRE
# ═══════════════════════════════════════════════════════════════

## 1. Fiók létrehozás

1. Menj: https://cloudinary.com/users/register/free
2. Regisztrálj (Google-lal is lehet)
3. A "Product Environment Name" legyen: optikart (vagy bármi)
4. Free plan: 25 GB storage, 25 GB bandwidth/hó – bőven elég kezdéshez

---

## 2. Dashboard adatok összegyűjtése

Bejelentkezés után: https://console.cloudinary.com/
A főoldalon látod:
- Cloud Name: pl. "dzXXXXXXX"
- API Key: 12 jegyű szám
- API Secret: hosszú string (szemre ne kattints)

---

## 3. Upload Preset létrehozás (unsigned feltöltéshez)

Ez teszi lehetővé hogy a böngésző KÖZVETLENÜL feltöltsön,
Vercel szervered ÉRINTÉSE NÉLKÜL.

Settings → Upload → Upload presets → Add upload preset

Beállítások:
  Preset name: optikart_gallery
  Signing mode: UNSIGNED  ← ez a fontos!
  Folder: galleries/
  Allowed formats: jpg, jpeg, png, webp, gif
  Max file size: 20 MB

Quality and optimization:
  ✅ Backup original
  ✅ Optimize on deliver

Eager transformations (cache-elve lesznek előre):
  Transformation 1: w_400,h_400,c_fill,q_auto,f_auto  (thumbnail)
  Transformation 2: w_1200,h_800,c_limit,q_auto,f_auto (preview)

→ Save preset
→ Másold ki a preset neve: "optikart_gallery"

---

## 4. Caching beállítás (FREE plan optimalizálás)

Settings → Security → Content Delivery
  ✅ Enable CDN caching
  Cache-Control: max-age=31536000 (1 év)

Settings → Upload → Default transformations
  ✅ Auto quality
  ✅ Auto format
  ✅ Client hints

Ez azt jelenti:
- Minden kép Cloudinary CDN-ről jön (Frankfurtból Magyarországra gyors)
- 1 évig cache-eli a böngésző
- Automatikusan WebP-t ad modern böngészőknek (kisebb fájl)
- Vercel EGYÁLTALÁN nem látja a képforgalmat

---

## 5. .env.local beállítások

CLOUDINARY_CLOUD_NAME=dzXXXXXXX
CLOUDINARY_API_KEY=123456789012
CLOUDINARY_API_SECRET=abcdefghijklmnopqrstuvwxyz
CLOUDINARY_UPLOAD_PRESET=optikart_gallery

# Frontend (böngészőből elérhető kell legyen!)
NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME=dzXXXXXXX
NEXT_PUBLIC_CLOUDINARY_UPLOAD_PRESET=optikart_gallery

---

## 6. npm csomag telepítés

npm install cloudinary
# A feltöltés browser-side, nincs szükség SDK-ra frontend oldalon
# A cloudinary csomag csak a szerver oldali signed URL generáláshoz kell

---

## 7. Prisma schema hozzáadás (schema.prisma végére)

model Gallery {
  id             Int       @id @default(autoincrement())
  createdAt      DateTime  @default(now())
  updatedAt      DateTime  @updatedAt

  title          String?
  description    String?
  coverImageUrl  String?   // Cloudinary URL

  projectId      Int
  project        Project   @relation(fields: [projectId], references: [id], onDelete: Cascade)

  # Megosztás
  shareToken     String    @unique @default(cuid())
  isPublic       Boolean   @default(false)

  # Jelszóvédelem
  password       String?   // bcrypt hash

  # Lejárat
  expiresAt      DateTime?

  images         GalleryImage[]
}

model GalleryImage {
  id             Int      @id @default(autoincrement())
  createdAt      DateTime @default(now())

  galleryId      Int
  gallery        Gallery  @relation(fields: [galleryId], references: [id], onDelete: Cascade)

  # Cloudinary adatok
  publicId       String   # pl. "galleries/abc123"
  originalUrl    String   # Cloudinary eredeti URL
  thumbnailUrl   String   # 400x400 crop URL
  previewUrl     String   # 1200x800 limit URL

  fileName       String?  # eredeti fájlnév
  width          Int?
  height         Int?
  bytes          Int?     # fájlméret bájtban

  sortOrder      Int      @default(0)
}

# Meglévő Project modellbe add hozzá:
# galleries  Gallery[]

---

## 8. npx prisma db push

Miután hozzáadtad a schema-t:
  npx prisma db push
  npx prisma generate
